/*
htop - openbsd/Battery.c
(C) 2015 Hisham H. Muhammad
(C) 2015 Michael McConville
Released under the GNU GPL, see the COPYING file
in the source distribution for its full text.
*/

#include "BatteryMeter.h"

void Battery_getData(double* level, ACPresence* isOnAC) {
   // TODO
   *level = -1;
   *isOnAC = AC_ERROR;
}

